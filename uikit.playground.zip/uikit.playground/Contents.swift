//Apparel app

var itemCount: Int = 0
var itemTotal: Double = 0.0
var taxRate : Double = 0.12
var taxOnItemTotal : Double = 0.0
var cartTotal : Double = 0.0

var firstItemName : String = "Shirt"
var firstItemPrice : Double = 1200
addItemToCart() //reusing the code using function
//itemCount = itemCount + 1
//itemTotal = itemTotal + firstItemPrice
//taxOnItemTotal = taxRate * itemTotal
//cartTotal = itemTotal + taxOnItemTotal

var secondItemName : String = "Trouser"
var secondItemPrice : Double = 2200
addItemToCart()

var thirdItemName : String = "Tie"
var thirdItemPrice : Double = 450
addItemToCart()

var fourthItemName : String = "Socks"
var fourthItemPrice : Double = 225
addItemToCart()

//Repeating a piece of code instead use functions

//Functions
//Writing maintainable and reusable code - increase the code readability
//Fundamental way of using Abstraction in Code.

//Define a function - using func keyword

func functionName(){
    //body of the function
   
}
//abstraction - hiding
//Function with no parameter
func addItemToCart() {
    //body
//    displaySuccessMessageWithItemName(itemName : firstItemName)
    displaySuccessMessage()
}

//call or invoke the function
addItemToCart()

//Function
func displaySuccessMessage() {
    print("Item added to the cart successfully!")
}

//Function with Parameter
func displaySuccessMessageWithItemName(itemName : String) {
    print("\(itemName) is added to the cart successfully!.")
}
//Here itemName is the function parameter
displaySuccessMessageWithItemName(itemName : firstItemName)
 
//Here firstItemName is the argument
//Argument is the value that we pass to the function parameter

//print(itemName)
//Scope of function parameter is only within the function
//Function with multiple parameter

func displaySuccessMessageWithItemNameAndPrice(itemName : String, itemPrice :Double) {
    print("\(itemName) with Price : \(itemPrice) is added to the cart successfully!.")
}

displaySuccessMessageWithItemNameAndPrice(itemName: secondItemName, itemPrice: secondItemPrice)



/*
 itemPrice and itemName is a Argument Labels(parameter name) in a function but not always.
displaySuccessMessageWithItemNameAndPrice(itemName, itemPrice)
cannot call a function without argument label if the parameters are named
expressive
*/
displaySuccessMessageWithItemNameAndPrice(itemName: thirdItemName,itemPrice: thirdItemPrice)

//displaySuccessMessageWithItemNameAndPrice(itemPrice: fourthItemPrice, itemName: fourthItemName)
//--> Cannot change the order of the arguments

//Another example of swift being expressive

//Argument Label
//itemName and itemPrice are used internally for function implementation
//with, and are used externally.
func displaySuccessMessage(with itemName: String, and itemPrice: Double) {
//    print("\(with) costing \(and) added to the cart successfully ")
    print("\(itemName) costing \(itemPrice) added to the cart successfully ")
}
displaySuccessMessage(with: fourthItemName, and: fourthItemPrice)

//omit argument labels.
func displaySuccessMessageFor(_ itemName: String, costing itemPrice: Double) {
    print("\(itemName) costing \(itemPrice) added to the cart successfully.")
}
displaySuccessMessageFor("Shoe", costing: 2000)

//return type
func calculateTaxOnItem(itemPrice: Double) -> Double {
    let taxOnItem = itemPrice * 0.12
    return taxOnItem
}

//func calculateTaxOnItem(itemPrice: Double) -> Double {
//    return itemPrice * 0.12
//}

//func calculateTaxOnItem(itemPrice: Double) -> Double {
//    itemPrice * 0.12
//}


//let calculatedTaxOnItem = calculateTaxOnItem(itemPrice: firstItemPrice)
//print("The tax on \(firstItemName) is \(calculatedTaxOnItem)")
//

print("The tax on \(firstItemName) is \(calculateTaxOnItem(itemPrice: firstItemPrice))")

//Default Value of Parameters

//func calculateTaxAndPlatformFee(itemPrice: Double, taxRate: Double = 0.12, platformFee: Double) {
//    print("Tax is \(itemPrice*taxRate)")
//    print("Platform Fee is \(itemPrice*platformFee)")
//}
calculateTaxAndPlatformFee(itemPrice: firstItemPrice, platformFee: 0.01)
//calculateTaxAndPlatformFee(itemPrice: secondItemPrice, taxRate: 0.23, platformFee: 0.12)
 
//function without argument label
/*
func calculateTaxAndPlatformFee(_ itemPrice: Double, _ platformFee: Double, _ taxRate: Double = 0.12) {
    print("Tax is \(itemPrice*taxRate)")
    print("Platform Fee is \(itemPrice*platformFee)")
}
*/
calculateTaxAndPlatformFee(itemPrice: 2000.0, platformFee: 0.01)

//If we are calling function without arguments labels and there are parameters with default value then that parameter should be named at the last after other parameters.

//mutliple value using return
//tuples and collections

//func calculateTaxAndPlatformFee(_ itemPrice: Double, _ platformFee: Double, _ taxRate: Double = 0.12) -> (Double, Double){
//    let taxOnItem = itemPrice * taxRate
//    let platformFeeOnItem = itemPrice * platformFee
////    print("Tax is \(itemPrice*taxRate)")
////    print("Platform Fee is \(itemPrice*platformFee)")
//    return (taxOnItem, platformFeeOnItem)
//}
// 
//
////calling
//
//let taxAndPlatformFee = calculateTaxAndPlatformFee(1500, 0.02)
//print("Tax is \(taxAndPlatformFee.0)")
//print("Platform fee is \(taxAndPlatformFee.1)")


func calculateTaxAndPlatformFee(itemPrice: Double, platformFee: Double, taxRate: Double = 0.12) -> (taxonItem: Double,platformFeeOnItem: Double){
    let tax = itemPrice * taxRate
    let platformFee = itemPrice * platformFee
//    print("Tax is \(itemPrice*taxRate)")
//    print("Platform Fee is \(itemPrice*platformFee)")
    return (tax, platformFee)
}


//calling the function using the name of tuple

let taxAndPlatformFee = calculateTaxAndPlatformFee(itemPrice: 1222, platformFee: 0.11)
print("Tax is \(taxAndPlatformFee.taxonItem)")
print("Platform fee is \(taxAndPlatformFee.platformFeeOnItem)")



